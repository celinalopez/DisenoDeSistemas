public interface ILibroMalEstado {
    public void update();
}
