public class Administracion implements ILibroMalEstado{

    @Override
    public void update() {
        System.out.println("Administracion: ");
        System.out.println("Suspensión de socio hasta la reposición o reparación del daño causado.....");
    }
}
